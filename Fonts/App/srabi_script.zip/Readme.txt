Hello,
This font is for FREE for PERSONAL USE ONLY! 

DONATION : https://www.paypal.me/salmanmashudi

COMMERCIAL License: 
https://fontbundles.net/hasta-type/303222-srabi-script

STORE: https://fontbundles.net/hasta-type

Question or EXTENDED License 
Email: falahudin234@gmail.com

PORTFOLIO 
- Instagram : https://www.instagram.com/hastatype/
- Behance : https://www.behance.net/HastaType

Thanks,
Hasta Type 


UTK WARGA INDONESIA: 

Apabila ingin menggunakan font ini untuk keperluan KOMERISAL, mohon untuk menghubungi saya di: 
email : falahudin234@gmail.com
HP : 081278886607 

Terima Kasih